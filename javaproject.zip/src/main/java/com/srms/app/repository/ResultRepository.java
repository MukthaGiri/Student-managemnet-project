package com.srms.app.repository;

import com.srms.app.model.Result;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ResultRepository extends JpaRepository<Result, Long> {

    List<Result> findByStudentId(Long studentId);

    List<Result> findBySubjectId(Long subjectId);

    Optional<Result> findByStudentIdAndSubjectIdAndExamType(Long studentId, Long subjectId, String examType);

    void deleteByStudentId(Long studentId);

    @Query("SELECT r FROM Result r WHERE r.student.id = :studentId ORDER BY r.subject.name")
    List<Result> findAllForStudentOrdered(@Param("studentId") Long studentId);

    @Query("SELECT AVG(r.marksObtained) FROM Result r WHERE r.student.id = :studentId")
    Double findAverageMarksForStudent(@Param("studentId") Long studentId);

    @Query("SELECT COUNT(r) FROM Result r WHERE r.student.id = :studentId AND r.passed = false")
    Long countFailedSubjects(@Param("studentId") Long studentId);
}
