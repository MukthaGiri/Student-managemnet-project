package com.srms.app.config;

import com.srms.app.model.Grade;
import com.srms.app.model.Result;
import com.srms.app.model.Student;
import com.srms.app.model.Subject;
import com.srms.app.repository.ResultRepository;
import com.srms.app.repository.StudentRepository;
import com.srms.app.repository.SubjectRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.time.LocalDate;

@Component
@RequiredArgsConstructor
public class DataSeeder implements CommandLineRunner {

    private final StudentRepository studentRepository;
    private final SubjectRepository subjectRepository;
    private final ResultRepository resultRepository;

    @Override
    public void run(String... args) {
        if (studentRepository.count() > 0) {
            return; // already seeded
        }

        // Subjects
        Subject maths = subjectRepository.save(new Subject(null, "CS101", "Mathematics I", 100, 40, 4, new java.util.ArrayList<>()));
        Subject physics = subjectRepository.save(new Subject(null, "CS102", "Physics", 100, 40, 3, new java.util.ArrayList<>()));
        Subject dsa = subjectRepository.save(new Subject(null, "CS103", "Data Structures", 100, 40, 4, new java.util.ArrayList<>()));
        Subject english = subjectRepository.save(new Subject(null, "HS101", "English Communication", 50, 20, 2, new java.util.ArrayList<>()));

        // Students
        Student s1 = studentRepository.save(new Student(null, "CS2024001", "Aarav Sharma",
                "aarav.sharma@example.com", "9876543210", "Computer Science", 3,
                LocalDate.of(2004, 5, 12), new java.util.ArrayList<>()));

        Student s2 = studentRepository.save(new Student(null, "CS2024002", "Priya Patel",
                "priya.patel@example.com", "9876543211", "Computer Science", 3,
                LocalDate.of(2004, 8, 23), new java.util.ArrayList<>()));

        Student s3 = studentRepository.save(new Student(null, "CS2024003", "Rohan Mehta",
                "rohan.mehta@example.com", "9876543212", "Computer Science", 3,
                LocalDate.of(2003, 11, 2), new java.util.ArrayList<>()));

        // Results for student 1 (strong performer)
        saveResult(s1, maths, 88);
        saveResult(s1, physics, 79);
        saveResult(s1, dsa, 95);
        saveResult(s1, english, 44);

        // Results for student 2 (average performer)
        saveResult(s2, maths, 62);
        saveResult(s2, physics, 55);
        saveResult(s2, dsa, 70);
        saveResult(s2, english, 30);

        // Results for student 3 (failing in one subject)
        saveResult(s3, maths, 35);
        saveResult(s3, physics, 48);
        saveResult(s3, dsa, 52);
        saveResult(s3, english, 25);
    }

    private void saveResult(Student student, Subject subject, double marks) {
        boolean passed = marks >= subject.getPassingMarks();
        double percentage = (marks / subject.getMaxMarks()) * 100.0;
        Grade grade = Grade.fromPercentage(percentage, passed);

        Result result = new Result();
        result.setStudent(student);
        result.setSubject(subject);
        result.setMarksObtained(marks);
        result.setExamType("FINAL");
        result.setPassed(passed);
        result.setGrade(grade);

        resultRepository.save(result);
    }
}
