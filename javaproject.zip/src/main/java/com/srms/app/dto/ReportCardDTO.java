package com.srms.app.dto;

import com.srms.app.model.Grade;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ReportCardDTO {
    private Long studentId;
    private String rollNumber;
    private String studentName;
    private String department;
    private Integer semester;

    private List<SubjectResultRow> subjectResults;

    private double totalMarksObtained;
    private double totalMaxMarks;
    private double overallPercentage;
    private Grade overallGrade;
    private boolean overallPassed;
    private long subjectsFailed;

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class SubjectResultRow {
        private String subjectCode;
        private String subjectName;
        private Double marksObtained;
        private Integer maxMarks;
        private Integer passingMarks;
        private double percentage;
        private Grade grade;
        private boolean passed;
    }
}
