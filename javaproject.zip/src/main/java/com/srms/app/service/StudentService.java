package com.srms.app.service;

import com.srms.app.dto.StudentDTO;
import com.srms.app.exception.DuplicateResourceException;
import com.srms.app.exception.ResourceNotFoundException;
import com.srms.app.model.Student;
import com.srms.app.repository.ResultRepository;
import com.srms.app.repository.StudentRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Transactional
public class StudentService {

    private final StudentRepository studentRepository;
    private final ResultRepository resultRepository;

    public List<StudentDTO> getAllStudents() {
        return studentRepository.findAll().stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }

    public StudentDTO getStudentById(Long id) {
        return toDTO(findStudentOrThrow(id));
    }

    public Student findStudentOrThrow(Long id) {
        return studentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Student not found with id: " + id));
    }

    public List<StudentDTO> searchStudents(String keyword) {
        if (keyword == null || keyword.isBlank()) {
            return getAllStudents();
        }
        return studentRepository.search(keyword.trim()).stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }

    public List<StudentDTO> getStudentsByDepartment(String department) {
        return studentRepository.findByDepartmentIgnoreCase(department).stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }

    public StudentDTO createStudent(StudentDTO dto) {
        if (studentRepository.existsByRollNumber(dto.getRollNumber())) {
            throw new DuplicateResourceException("Student with roll number '" + dto.getRollNumber() + "' already exists");
        }
        Student student = fromDTO(dto);
        student.setId(null);
        Student saved = studentRepository.save(student);
        return toDTO(saved);
    }

    public StudentDTO updateStudent(Long id, StudentDTO dto) {
        Student existing = findStudentOrThrow(id);

        // If roll number is changing, ensure no clash with another student
        if (!existing.getRollNumber().equalsIgnoreCase(dto.getRollNumber())
                && studentRepository.existsByRollNumber(dto.getRollNumber())) {
            throw new DuplicateResourceException("Student with roll number '" + dto.getRollNumber() + "' already exists");
        }

        existing.setRollNumber(dto.getRollNumber());
        existing.setName(dto.getName());
        existing.setEmail(dto.getEmail());
        existing.setPhone(dto.getPhone());
        existing.setDepartment(dto.getDepartment());
        existing.setSemester(dto.getSemester());
        existing.setDateOfBirth(dto.getDateOfBirth());

        return toDTO(studentRepository.save(existing));
    }

    public void deleteStudent(Long id) {
        Student student = findStudentOrThrow(id);
        resultRepository.deleteByStudentId(student.getId());
        studentRepository.delete(student);
    }

    private StudentDTO toDTO(Student s) {
        return new StudentDTO(s.getId(), s.getRollNumber(), s.getName(), s.getEmail(),
                s.getPhone(), s.getDepartment(), s.getSemester(), s.getDateOfBirth());
    }

    private Student fromDTO(StudentDTO d) {
        Student s = new Student();
        s.setId(d.getId());
        s.setRollNumber(d.getRollNumber());
        s.setName(d.getName());
        s.setEmail(d.getEmail());
        s.setPhone(d.getPhone());
        s.setDepartment(d.getDepartment());
        s.setSemester(d.getSemester());
        s.setDateOfBirth(d.getDateOfBirth());
        return s;
    }
}
