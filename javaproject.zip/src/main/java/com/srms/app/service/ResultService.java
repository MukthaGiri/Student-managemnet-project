package com.srms.app.service;

import com.srms.app.dto.ReportCardDTO;
import com.srms.app.dto.ResultDTO;
import com.srms.app.exception.DuplicateResourceException;
import com.srms.app.exception.ResourceNotFoundException;
import com.srms.app.model.Grade;
import com.srms.app.model.Result;
import com.srms.app.model.Student;
import com.srms.app.model.Subject;
import com.srms.app.repository.ResultRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Transactional
public class ResultService {

    private final ResultRepository resultRepository;
    private final StudentService studentService;
    private final SubjectService subjectService;

    public List<Result> getAllResults() {
        return resultRepository.findAll();
    }

    public Result getResultById(Long id) {
        return resultRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Result not found with id: " + id));
    }

    public Result saveResult(ResultDTO dto) {
        Student student = studentService.findStudentOrThrow(dto.getStudentId());
        Subject subject = subjectService.findSubjectOrThrow(dto.getSubjectId());

        String examType = (dto.getExamType() == null || dto.getExamType().isBlank()) ? "FINAL" : dto.getExamType();

        if (dto.getId() == null
                && resultRepository.findByStudentIdAndSubjectIdAndExamType(student.getId(), subject.getId(), examType).isPresent()) {
            throw new DuplicateResourceException(
                    "Result already exists for this student, subject, and exam type. Use update instead.");
        }

        if (dto.getMarksObtained() > subject.getMaxMarks()) {
            throw new IllegalArgumentException(
                    "Marks obtained (" + dto.getMarksObtained() + ") cannot exceed max marks (" + subject.getMaxMarks() + ") for " + subject.getName());
        }

        Result result;
        if (dto.getId() != null) {
            result = getResultById(dto.getId());
        } else {
            result = new Result();
        }

        result.setStudent(student);
        result.setSubject(subject);
        result.setMarksObtained(dto.getMarksObtained());
        result.setExamType(examType);

        boolean passed = dto.getMarksObtained() >= subject.getPassingMarks();
        double percentage = (dto.getMarksObtained() / subject.getMaxMarks()) * 100.0;

        result.setPassed(passed);
        result.setGrade(Grade.fromPercentage(percentage, passed));

        return resultRepository.save(result);
    }

    public void deleteResult(Long id) {
        Result result = getResultById(id);
        resultRepository.delete(result);
    }

    public List<Result> getResultsForStudent(Long studentId) {
        studentService.findStudentOrThrow(studentId);
        return resultRepository.findAllForStudentOrdered(studentId);
    }

    public ReportCardDTO generateReportCard(Long studentId) {
        Student student = studentService.findStudentOrThrow(studentId);
        List<Result> results = resultRepository.findAllForStudentOrdered(studentId);

        List<ReportCardDTO.SubjectResultRow> rows = results.stream().map(r -> {
            double pct = r.getPercentage();
            return new ReportCardDTO.SubjectResultRow(
                    r.getSubject().getCode(),
                    r.getSubject().getName(),
                    r.getMarksObtained(),
                    r.getSubject().getMaxMarks(),
                    r.getSubject().getPassingMarks(),
                    Math.round(pct * 100) / 100.0,
                    r.getGrade(),
                    Boolean.TRUE.equals(r.getPassed())
            );
        }).collect(Collectors.toList());

        double totalObtained = results.stream().mapToDouble(Result::getMarksObtained).sum();
        double totalMax = results.stream().mapToDouble(r -> r.getSubject().getMaxMarks()).sum();
        double overallPct = totalMax > 0 ? (totalObtained / totalMax) * 100.0 : 0.0;
        long failedCount = results.stream().filter(r -> !Boolean.TRUE.equals(r.getPassed())).count();
        boolean overallPassed = failedCount == 0 && !results.isEmpty();

        ReportCardDTO card = new ReportCardDTO();
        card.setStudentId(student.getId());
        card.setRollNumber(student.getRollNumber());
        card.setStudentName(student.getName());
        card.setDepartment(student.getDepartment());
        card.setSemester(student.getSemester());
        card.setSubjectResults(rows);
        card.setTotalMarksObtained(totalObtained);
        card.setTotalMaxMarks(totalMax);
        card.setOverallPercentage(Math.round(overallPct * 100) / 100.0);
        card.setOverallGrade(Grade.fromPercentage(overallPct, overallPassed));
        card.setOverallPassed(overallPassed);
        card.setSubjectsFailed(failedCount);

        return card;
    }
}
