package com.srms.app.service;

import com.srms.app.exception.DuplicateResourceException;
import com.srms.app.exception.ResourceNotFoundException;
import com.srms.app.model.Subject;
import com.srms.app.repository.SubjectRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
@Transactional
public class SubjectService {

    private final SubjectRepository subjectRepository;

    public List<Subject> getAllSubjects() {
        return subjectRepository.findAll();
    }

    public Subject getSubjectById(Long id) {
        return findSubjectOrThrow(id);
    }

    public Subject findSubjectOrThrow(Long id) {
        return subjectRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Subject not found with id: " + id));
    }

    public Subject createSubject(Subject subject) {
        if (subjectRepository.existsByCode(subject.getCode())) {
            throw new DuplicateResourceException("Subject with code '" + subject.getCode() + "' already exists");
        }
        subject.setId(null);
        return subjectRepository.save(subject);
    }

    public Subject updateSubject(Long id, Subject updated) {
        Subject existing = findSubjectOrThrow(id);

        if (!existing.getCode().equalsIgnoreCase(updated.getCode())
                && subjectRepository.existsByCode(updated.getCode())) {
            throw new DuplicateResourceException("Subject with code '" + updated.getCode() + "' already exists");
        }

        existing.setCode(updated.getCode());
        existing.setName(updated.getName());
        existing.setMaxMarks(updated.getMaxMarks());
        existing.setPassingMarks(updated.getPassingMarks());
        existing.setCredits(updated.getCredits());
        return subjectRepository.save(existing);
    }

    public void deleteSubject(Long id) {
        Subject subject = findSubjectOrThrow(id);
        subjectRepository.delete(subject);
    }
}
