package com.srms.app.controller;

import com.srms.app.dto.ReportCardDTO;
import com.srms.app.dto.ResultDTO;
import com.srms.app.model.Result;
import com.srms.app.service.ResultService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/results")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class ResultController {

    private final ResultService resultService;

    @GetMapping
    public ResponseEntity<List<Result>> getAllResults() {
        return ResponseEntity.ok(resultService.getAllResults());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Result> getResultById(@PathVariable Long id) {
        return ResponseEntity.ok(resultService.getResultById(id));
    }

    @GetMapping("/student/{studentId}")
    public ResponseEntity<List<Result>> getResultsForStudent(@PathVariable Long studentId) {
        return ResponseEntity.ok(resultService.getResultsForStudent(studentId));
    }

    @GetMapping("/student/{studentId}/report-card")
    public ResponseEntity<ReportCardDTO> getReportCard(@PathVariable Long studentId) {
        return ResponseEntity.ok(resultService.generateReportCard(studentId));
    }

    @PostMapping
    public ResponseEntity<Result> createResult(@Valid @RequestBody ResultDTO dto) {
        Result created = resultService.saveResult(dto);
        return ResponseEntity.status(HttpStatus.CREATED).body(created);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Result> updateResult(@PathVariable Long id, @Valid @RequestBody ResultDTO dto) {
        dto.setId(id);
        return ResponseEntity.ok(resultService.saveResult(dto));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteResult(@PathVariable Long id) {
        resultService.deleteResult(id);
        return ResponseEntity.noContent().build();
    }
}
