package com.srms.app.model;

public enum Grade {
    O,    // Outstanding   90-100
    A_PLUS, // 80-89
    A,    // 70-79
    B_PLUS, // 60-69
    B,    // 50-59
    C,    // 40-49
    F;    // below passing marks

    public static Grade fromPercentage(double percentage, boolean passed) {
        if (!passed) return F;
        if (percentage >= 90) return O;
        if (percentage >= 80) return A_PLUS;
        if (percentage >= 70) return A;
        if (percentage >= 60) return B_PLUS;
        if (percentage >= 50) return B;
        return C;
    }
}
