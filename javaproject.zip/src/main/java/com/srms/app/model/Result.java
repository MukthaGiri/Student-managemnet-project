package com.srms.app.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "results", uniqueConstraints = {
        @UniqueConstraint(columnNames = {"student_id", "subject_id", "exam_type"})
})
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Result {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "student_id", nullable = false)
    @NotNull(message = "Student is required")
    private Student student;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "subject_id", nullable = false)
    @NotNull(message = "Subject is required")
    private Subject subject;

    @NotNull(message = "Marks obtained is required")
    @Min(value = 0, message = "Marks cannot be negative")
    @Column(name = "marks_obtained", nullable = false)
    private Double marksObtained;

    @Column(name = "exam_type", length = 30)
    private String examType = "FINAL";

    @Enumerated(EnumType.STRING)
    private Grade grade;

    private Boolean passed;

    @Transient
    public double getPercentage() {
        if (subject == null || subject.getMaxMarks() == 0) return 0;
        return (marksObtained / subject.getMaxMarks()) * 100.0;
    }
}
