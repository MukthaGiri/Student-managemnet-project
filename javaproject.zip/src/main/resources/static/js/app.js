/* ============================================================
   Akademos — front-end logic
   Vanilla JS, talks to the Spring Boot REST API at /api/**
   ============================================================ */

const API = {
  students: '/api/students',
  subjects: '/api/subjects',
  results: '/api/results',
};

const state = {
  students: [],
  subjects: [],
  results: [],
};

/* ---------------------- helpers ---------------------- */

async function apiFetch(url, options = {}) {
  const res = await fetch(url, {
    headers: { 'Content-Type': 'application/json' },
    ...options,
  });
  const isJson = res.headers.get('content-type')?.includes('application/json');
  const body = isJson ? await res.json().catch(() => null) : null;

  if (!res.ok) {
    const message = body?.message || body?.error || `Request failed (${res.status})`;
    if (body?.fieldErrors) {
      const details = Object.entries(body.fieldErrors).map(([k, v]) => `${k}: ${v}`).join(' · ');
      throw new Error(details || message);
    }
    throw new Error(message);
  }
  return body;
}

function showToast(message, isError = false) {
  const toast = document.getElementById('toast');
  toast.textContent = message;
  toast.classList.toggle('error', isError);
  toast.classList.add('show');
  clearTimeout(toast._timer);
  toast._timer = setTimeout(() => toast.classList.remove('show'), 3200);
}

function escapeHtml(str) {
  if (str === null || str === undefined) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function gradeLabel(g) {
  if (!g) return '—';
  return g.replace('_PLUS', '+').replace('_', '');
}

/* ---------------------- navigation ---------------------- */

const views = ['dashboard', 'students', 'subjects', 'results', 'reportcard'];
const titles = {
  dashboard: ['Dashboard', 'Overview of academic performance'],
  students: ['Students', 'Manage student enrolment records'],
  subjects: ['Subjects', 'Define courses, marks, and grading thresholds'],
  results: ['Results Entry', 'Record and review examination marks'],
  reportcard: ['Report Card', 'Generate a consolidated result summary'],
};

function switchView(view) {
  views.forEach(v => {
    document.getElementById(`view-${v}`).classList.toggle('active', v === view);
  });
  document.querySelectorAll('.nav-item').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.view === view);
  });
  const [title, subtitle] = titles[view];
  document.getElementById('view-title').textContent = title;
  document.getElementById('view-subtitle').textContent = subtitle;

  if (view === 'dashboard') renderDashboard();
  if (view === 'students') renderStudentsTable();
  if (view === 'subjects') renderSubjectsTable();
  if (view === 'results') renderResultsView();
  if (view === 'reportcard') renderReportCardSelectors();
}

document.querySelectorAll('.nav-item').forEach(btn => {
  btn.addEventListener('click', () => switchView(btn.dataset.view));
});

/* ---------------------- data loading ---------------------- */

async function loadAll() {
  try {
    const [students, subjects, results] = await Promise.all([
      apiFetch(API.students),
      apiFetch(API.subjects),
      apiFetch(API.results),
    ]);
    state.students = students;
    state.subjects = subjects;
    state.results = results;
  } catch (err) {
    showToast(err.message, true);
  }
}

/* ---------------------- DASHBOARD ---------------------- */

function renderDashboard() {
  document.getElementById('stat-students').textContent = state.students.length;
  document.getElementById('stat-subjects').textContent = state.subjects.length;
  document.getElementById('stat-results').textContent = state.results.length;

  const passed = state.results.filter(r => r.passed).length;
  const rate = state.results.length ? Math.round((passed / state.results.length) * 100) : 0;
  document.getElementById('stat-passrate').textContent = state.results.length ? `${rate}%` : '—';

  const tbody = document.querySelector('#dashboard-table tbody');
  const recent = [...state.students].slice(-6).reverse();

  if (!recent.length) {
    tbody.innerHTML = `<tr class="empty-row"><td colspan="5">No students enrolled yet. Add one from the Students tab.</td></tr>`;
    return;
  }

  tbody.innerHTML = recent.map(s => `
    <tr>
      <td class="mono">${escapeHtml(s.rollNumber)}</td>
      <td>${escapeHtml(s.name)}</td>
      <td>${escapeHtml(s.department)}</td>
      <td class="mono">${s.semester ?? '—'}</td>
      <td><button class="btn-text" data-goto-report="${s.id}">View report →</button></td>
    </tr>
  `).join('');

  tbody.querySelectorAll('[data-goto-report]').forEach(btn => {
    btn.addEventListener('click', () => {
      switchView('reportcard');
      document.getElementById('reportcard-student').value = btn.dataset.gotoReport;
      generateReportCard();
    });
  });
}

/* ---------------------- STUDENTS ---------------------- */

function renderStudentsTable(list = state.students) {
  const tbody = document.querySelector('#students-table tbody');
  if (!list.length) {
    tbody.innerHTML = `<tr class="empty-row"><td colspan="6">No students found.</td></tr>`;
    return;
  }
  tbody.innerHTML = list.map(s => `
    <tr>
      <td class="mono">${escapeHtml(s.rollNumber)}</td>
      <td>${escapeHtml(s.name)}</td>
      <td>${escapeHtml(s.email || '—')}</td>
      <td>${escapeHtml(s.department)}</td>
      <td class="mono">${s.semester ?? '—'}</td>
      <td>
        <button class="btn-text" data-edit-student="${s.id}">Edit</button>
        <button class="btn-text danger" data-delete-student="${s.id}">Delete</button>
      </td>
    </tr>
  `).join('');

  tbody.querySelectorAll('[data-edit-student]').forEach(btn =>
    btn.addEventListener('click', () => openStudentModal(btn.dataset.editStudent)));
  tbody.querySelectorAll('[data-delete-student]').forEach(btn =>
    btn.addEventListener('click', () => deleteStudent(btn.dataset.deleteStudent)));
}

document.getElementById('student-search').addEventListener('input', (e) => {
  const term = e.target.value.toLowerCase().trim();
  if (!term) return renderStudentsTable();
  const filtered = state.students.filter(s =>
    s.name.toLowerCase().includes(term) || s.rollNumber.toLowerCase().includes(term));
  renderStudentsTable(filtered);
});

function openStudentModal(id = null) {
  const student = id ? state.students.find(s => String(s.id) === String(id)) : null;
  document.getElementById('modal-title').textContent = student ? 'Edit Student' : 'New Student';

  document.getElementById('modal-body').innerHTML = `
    <form id="student-form" class="form-grid">
      <label>Roll Number
        <input type="text" id="f-rollNumber" value="${escapeHtml(student?.rollNumber || '')}" required>
      </label>
      <label>Full Name
        <input type="text" id="f-name" value="${escapeHtml(student?.name || '')}" required>
      </label>
      <label>Email
        <input type="email" id="f-email" value="${escapeHtml(student?.email || '')}">
      </label>
      <label>Phone
        <input type="text" id="f-phone" value="${escapeHtml(student?.phone || '')}">
      </label>
      <label>Department
        <input type="text" id="f-department" value="${escapeHtml(student?.department || '')}" required>
      </label>
      <label>Semester
        <input type="number" id="f-semester" min="1" max="12" value="${student?.semester ?? ''}">
      </label>
      <label>Date of Birth
        <input type="date" id="f-dob" value="${student?.dateOfBirth || ''}">
      </label>
      <div class="form-actions">
        <button type="button" class="btn btn-ghost" id="student-cancel">Cancel</button>
        <button type="submit" class="btn btn-primary">${student ? 'Save Changes' : 'Add Student'}</button>
      </div>
    </form>
  `;

  openModal();

  document.getElementById('student-cancel').addEventListener('click', closeModal);
  document.getElementById('student-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const payload = {
      rollNumber: document.getElementById('f-rollNumber').value.trim(),
      name: document.getElementById('f-name').value.trim(),
      email: document.getElementById('f-email').value.trim() || null,
      phone: document.getElementById('f-phone').value.trim() || null,
      department: document.getElementById('f-department').value.trim(),
      semester: document.getElementById('f-semester').value ? Number(document.getElementById('f-semester').value) : null,
      dateOfBirth: document.getElementById('f-dob').value || null,
    };

    try {
      if (student) {
        await apiFetch(`${API.students}/${student.id}`, { method: 'PUT', body: JSON.stringify(payload) });
        showToast('Student updated.');
      } else {
        await apiFetch(API.students, { method: 'POST', body: JSON.stringify(payload) });
        showToast('Student added.');
      }
      closeModal();
      await loadAll();
      renderStudentsTable();
      populateAllDropdowns();
    } catch (err) {
      showToast(err.message, true);
    }
  });
}

async function deleteStudent(id) {
  const student = state.students.find(s => String(s.id) === String(id));
  if (!confirm(`Delete student "${student?.name}"? This also removes their recorded results.`)) return;
  try {
    await apiFetch(`${API.students}/${id}`, { method: 'DELETE' });
    showToast('Student deleted.');
    await loadAll();
    renderStudentsTable();
    populateAllDropdowns();
  } catch (err) {
    showToast(err.message, true);
  }
}

document.getElementById('btn-new-student').addEventListener('click', () => openStudentModal());

/* ---------------------- SUBJECTS ---------------------- */

function renderSubjectsTable() {
  const tbody = document.querySelector('#subjects-table tbody');
  if (!state.subjects.length) {
    tbody.innerHTML = `<tr class="empty-row"><td colspan="6">No subjects defined yet.</td></tr>`;
    return;
  }
  tbody.innerHTML = state.subjects.map(s => `
    <tr>
      <td class="mono">${escapeHtml(s.code)}</td>
      <td>${escapeHtml(s.name)}</td>
      <td class="mono">${s.maxMarks}</td>
      <td class="mono">${s.passingMarks}</td>
      <td class="mono">${s.credits ?? '—'}</td>
      <td>
        <button class="btn-text" data-edit-subject="${s.id}">Edit</button>
        <button class="btn-text danger" data-delete-subject="${s.id}">Delete</button>
      </td>
    </tr>
  `).join('');

  tbody.querySelectorAll('[data-edit-subject]').forEach(btn =>
    btn.addEventListener('click', () => openSubjectModal(btn.dataset.editSubject)));
  tbody.querySelectorAll('[data-delete-subject]').forEach(btn =>
    btn.addEventListener('click', () => deleteSubject(btn.dataset.deleteSubject)));
}

function openSubjectModal(id = null) {
  const subject = id ? state.subjects.find(s => String(s.id) === String(id)) : null;
  document.getElementById('modal-title').textContent = subject ? 'Edit Subject' : 'New Subject';

  document.getElementById('modal-body').innerHTML = `
    <form id="subject-form" class="form-grid">
      <label>Subject Code
        <input type="text" id="f-code" value="${escapeHtml(subject?.code || '')}" required>
      </label>
      <label>Subject Name
        <input type="text" id="f-sname" value="${escapeHtml(subject?.name || '')}" required>
      </label>
      <label>Max Marks
        <input type="number" id="f-maxmarks" min="1" value="${subject?.maxMarks ?? 100}" required>
      </label>
      <label>Passing Marks
        <input type="number" id="f-passmarks" min="0" value="${subject?.passingMarks ?? 40}" required>
      </label>
      <label>Credits
        <input type="number" id="f-credits" min="0" max="10" value="${subject?.credits ?? 3}">
      </label>
      <div class="form-actions">
        <button type="button" class="btn btn-ghost" id="subject-cancel">Cancel</button>
        <button type="submit" class="btn btn-primary">${subject ? 'Save Changes' : 'Add Subject'}</button>
      </div>
    </form>
  `;

  openModal();

  document.getElementById('subject-cancel').addEventListener('click', closeModal);
  document.getElementById('subject-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const payload = {
      code: document.getElementById('f-code').value.trim(),
      name: document.getElementById('f-sname').value.trim(),
      maxMarks: Number(document.getElementById('f-maxmarks').value),
      passingMarks: Number(document.getElementById('f-passmarks').value),
      credits: Number(document.getElementById('f-credits').value || 0),
    };
    try {
      if (subject) {
        await apiFetch(`${API.subjects}/${subject.id}`, { method: 'PUT', body: JSON.stringify(payload) });
        showToast('Subject updated.');
      } else {
        await apiFetch(API.subjects, { method: 'POST', body: JSON.stringify(payload) });
        showToast('Subject added.');
      }
      closeModal();
      await loadAll();
      renderSubjectsTable();
      populateAllDropdowns();
    } catch (err) {
      showToast(err.message, true);
    }
  });
}

async function deleteSubject(id) {
  const subject = state.subjects.find(s => String(s.id) === String(id));
  if (!confirm(`Delete subject "${subject?.name}"? Existing results for it will also be removed.`)) return;
  try {
    await apiFetch(`${API.subjects}/${id}`, { method: 'DELETE' });
    showToast('Subject deleted.');
    await loadAll();
    renderSubjectsTable();
    populateAllDropdowns();
  } catch (err) {
    showToast(err.message, true);
  }
}

document.getElementById('btn-new-subject').addEventListener('click', () => openSubjectModal());

/* ---------------------- RESULTS ---------------------- */

function populateAllDropdowns() {
  const studentOptions = state.students
    .map(s => `<option value="${s.id}">${escapeHtml(s.rollNumber)} — ${escapeHtml(s.name)}</option>`)
    .join('');
  const subjectOptions = state.subjects
    .map(s => `<option value="${s.id}">${escapeHtml(s.code)} — ${escapeHtml(s.name)} (max ${s.maxMarks})</option>`)
    .join('');

  const studentSelects = ['result-student', 'reportcard-student'];
  studentSelects.forEach(id => {
    const el = document.getElementById(id);
    const current = el.value;
    el.innerHTML = state.students.length
      ? studentOptions
      : `<option value="">No students yet</option>`;
    if (current) el.value = current;
  });

  const subjectSelect = document.getElementById('result-subject');
  const currentSubject = subjectSelect.value;
  subjectSelect.innerHTML = state.subjects.length
    ? subjectOptions
    : `<option value="">No subjects yet</option>`;
  if (currentSubject) subjectSelect.value = currentSubject;
}

function renderResultsView() {
  populateAllDropdowns();
  renderResultsTable();
}

function renderResultsTable() {
  const tbody = document.querySelector('#results-table tbody');
  if (!state.results.length) {
    tbody.innerHTML = `<tr class="empty-row"><td colspan="9">No results recorded yet.</td></tr>`;
    return;
  }

  tbody.innerHTML = state.results.map(r => {
    const pct = r.subject?.maxMarks ? Math.round((r.marksObtained / r.subject.maxMarks) * 1000) / 10 : 0;
    return `
    <tr>
      <td class="mono">${escapeHtml(r.student?.rollNumber)}</td>
      <td>${escapeHtml(r.student?.name)}</td>
      <td>${escapeHtml(r.subject?.name)}</td>
      <td class="mono">${escapeHtml(r.examType || 'FINAL')}</td>
      <td class="mono">${r.marksObtained} / ${r.subject?.maxMarks}</td>
      <td class="mono">${pct}%</td>
      <td><span class="grade-pill">${gradeLabel(r.grade)}</span></td>
      <td><span class="badge ${r.passed ? 'badge-pass' : 'badge-fail'}">${r.passed ? 'Pass' : 'Fail'}</span></td>
      <td><button class="btn-text danger" data-delete-result="${r.id}">Delete</button></td>
    </tr>
  `;
  }).join('');

  tbody.querySelectorAll('[data-delete-result]').forEach(btn =>
    btn.addEventListener('click', () => deleteResult(btn.dataset.deleteResult)));
}

document.getElementById('result-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const payload = {
    studentId: Number(document.getElementById('result-student').value),
    subjectId: Number(document.getElementById('result-subject').value),
    examType: document.getElementById('result-examtype').value.trim() || 'FINAL',
    marksObtained: Number(document.getElementById('result-marks').value),
  };

  if (!payload.studentId || !payload.subjectId) {
    showToast('Please add a student and subject first.', true);
    return;
  }

  try {
    await apiFetch(API.results, { method: 'POST', body: JSON.stringify(payload) });
    showToast('Result saved.');
    document.getElementById('result-marks').value = '';
    await loadAll();
    renderResultsTable();
  } catch (err) {
    showToast(err.message, true);
  }
});

async function deleteResult(id) {
  if (!confirm('Delete this result entry?')) return;
  try {
    await apiFetch(`${API.results}/${id}`, { method: 'DELETE' });
    showToast('Result deleted.');
    await loadAll();
    renderResultsTable();
  } catch (err) {
    showToast(err.message, true);
  }
}

/* ---------------------- REPORT CARD ---------------------- */

function renderReportCardSelectors() {
  populateAllDropdowns();
}

document.getElementById('btn-generate-report').addEventListener('click', generateReportCard);

async function generateReportCard() {
  const studentId = document.getElementById('reportcard-student').value;
  const output = document.getElementById('reportcard-output');

  if (!studentId) {
    showToast('Select a student first.', true);
    return;
  }

  try {
    const card = await apiFetch(`${API.results}/student/${studentId}/report-card`);

    if (!card.subjectResults.length) {
      output.innerHTML = `
        <div class="empty-state">
          <span class="mark">§</span>
          No results recorded for ${escapeHtml(card.studentName)} yet.
        </div>`;
      return;
    }

    const rows = card.subjectResults.map(r => `
      <tr>
        <td class="mono">${escapeHtml(r.subjectCode)}</td>
        <td>${escapeHtml(r.subjectName)}</td>
        <td class="mono">${r.marksObtained} / ${r.maxMarks}</td>
        <td class="mono">${r.percentage}%</td>
        <td><span class="grade-pill">${gradeLabel(r.grade)}</span></td>
        <td><span class="badge ${r.passed ? 'badge-pass' : 'badge-fail'}">${r.passed ? 'Pass' : 'Fail'}</span></td>
      </tr>
    `).join('');

    output.innerHTML = `
      <div class="report-card">
        <div class="report-head">
          <div>
            <h2>${escapeHtml(card.studentName)}</h2>
            <div class="meta">
              Roll No. ${escapeHtml(card.rollNumber)} &nbsp;·&nbsp; ${escapeHtml(card.department)}
              ${card.semester ? `&nbsp;·&nbsp; Semester ${card.semester}` : ''}
            </div>
          </div>
          <div class="report-seal">
            <span class="seal-grade">${gradeLabel(card.overallGrade)}</span>
            <span class="seal-label">${card.overallPassed ? 'Passed' : 'Failed'}</span>
          </div>
        </div>
        <div class="report-body">
          <table>
            <thead>
              <tr><th>Code</th><th>Subject</th><th>Marks</th><th>%</th><th>Grade</th><th>Status</th></tr>
            </thead>
            <tbody>${rows}</tbody>
          </table>
        </div>
        <div class="report-foot">
          <div>
            ${card.subjectsFailed > 0
              ? `<span class="badge badge-fail">${card.subjectsFailed} subject(s) failed</span>`
              : `<span class="badge badge-pass">All subjects cleared</span>`}
          </div>
          <div class="total-block">
            <div class="total-label">Overall — ${card.totalMarksObtained} / ${card.totalMaxMarks}</div>
            <div class="total-value">${card.overallPercentage}%</div>
          </div>
        </div>
      </div>
    `;
  } catch (err) {
    showToast(err.message, true);
  }
}

/* ---------------------- MODAL ---------------------- */

function openModal() {
  document.getElementById('modal-overlay').classList.add('open');
}
function closeModal() {
  document.getElementById('modal-overlay').classList.remove('open');
  document.getElementById('modal-body').innerHTML = '';
}
document.getElementById('modal-close').addEventListener('click', closeModal);
document.getElementById('modal-overlay').addEventListener('click', (e) => {
  if (e.target.id === 'modal-overlay') closeModal();
});
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') closeModal();
});

/* ---------------------- INIT ---------------------- */

(async function init() {
  await loadAll();
  populateAllDropdowns();
  renderDashboard();
})();
